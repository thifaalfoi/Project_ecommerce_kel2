import { Input, Ripple, initMDB } from "mdb-ui-kit";

initMDB({ Input, Ripple });

